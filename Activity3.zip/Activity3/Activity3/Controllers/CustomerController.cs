﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using CustomerModels = Activity3.Models.CustomerModel;

using static System.Tuple;



namespace Activity3.Controllers
{
    public class CustomerController : Controller
    {
        private List<CustomerModels> customers { get; set; }
        
        public CustomerController()
        {
            CustomerModels cust1 = new CustomerModels(1, "Zack Chambers", 25);
            CustomerModels cust2 = new CustomerModels(2, "Michael Scott", 26);
            CustomerModels cust3 = new CustomerModels(3, "Bruce Willis", 24);

            customers = new List<CustomerModels>();

            customers.Add(cust1);
            customers.Add(cust2);
            customers.Add(cust3);
        }

        // GET: Customer
        public ActionResult Index()
        {

            Tuple<List<CustomerModels>, CustomerModels> tuple = new Tuple<List<CustomerModels>, CustomerModels>(customers, customers[0]);

            return View(tuple);
        }

        [HttpPost]
        public PartialViewResult OnSelectCustomer(string Item1)
        {
            int id = Int32.Parse(Item1);
            CustomerModels cust = customers.Where(i => i.ID == id).First();

            Tuple<List<CustomerModels>, CustomerModels> tuple = new Tuple<List<CustomerModels>, CustomerModels>(this.customers, cust);

            return PartialView("_CustomerDetails", tuple.Item2);
        }

        [HttpPost]
        public string GetMoreInfo(string customer) {
          
            return customer + " Success!";
        }
    }
}
﻿SELECT * FROM dbo.Users
INSERT INTO dbo.Users (USERNAME, PASSWORD) VALUES ('test', 'test')
﻿using BibleBenchmarkApp.Services.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

/* Zack Chambers CST-247 11/01/2020
 * This controller sends you home.
 */
namespace BibleBenchmarkApp.Controllers
{
    public class HomeController : Controller
    {
        [Unity.Dependency]
        public ILogger logger = new MyLogger2();

        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
    }
}
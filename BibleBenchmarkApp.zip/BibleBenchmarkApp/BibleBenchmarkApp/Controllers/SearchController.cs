﻿using BibleBenchmarkApp.Models;
using BibleBenchmarkApp.Services.Business;
using BibleBenchmarkApp.Services.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


/* Zack Chambers CST-247 11/01/2020
 * This controller manages user searches.
 */
namespace BibleBenchmarkApp.Controllers
{
    public class SearchController : Controller
    {
        [Unity.Dependency]
        public ILogger logger = new MyLogger2();

        // GET: Search
        public ActionResult Index() {
            return View();
        }

        // POST: Verse searching
        [HttpPost]
        public ActionResult Search(VerseModel model) {
            if (!ModelState.IsValid) {
                return View("Index");
            }

            VerseService service = new VerseService(model);
            List<string> text = service.SearchVerses();
            return View("Results", text);
        }
    }
}
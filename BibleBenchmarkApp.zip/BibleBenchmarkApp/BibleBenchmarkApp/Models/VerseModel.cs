﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

/* Zack Chambers CST-247 11/01/2020
 * The VerseModel contains all the getters and setters
 * for different verse properties and the validation rules
 * for each of those properties.
 */
namespace BibleBenchmarkApp.Models {
    public class VerseModel {
        [Required]
        [DisplayName("Testament")]
        [DefaultValue("")]
        public string Testament { get; set; }

        [Required]
        [DisplayName("Book")]
        [DefaultValue("")]
        public string Book { get; set; }

        [Required]
        [DisplayName("Chapter")]
        [DefaultValue("")]
        public int Chapter { get; set; }

        [Required]
        [DisplayName("Verse")]
        [DefaultValue("")]
        public int Verse { get; set; }
        
        [DisplayName("Text")]
        [StringLength(500, MinimumLength = 5)]
        [DefaultValue("")]
        public string Text { get; set; }
    }
}
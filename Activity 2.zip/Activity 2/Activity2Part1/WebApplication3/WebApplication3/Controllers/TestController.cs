﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication3.Models;


namespace WebApplication3.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
            
            
        {
            List<UserModel> users = new List<UserModel>();
            UserModel u1 = new UserModel("Zack", "zack@net.net", "0000000000");
            UserModel u2 = new UserModel("Tom", "tom@net.net", "1111111111");
            UserModel u3 = new UserModel("Scott", "scott@net.net", "2222222222");
            UserModel u4 = new UserModel("Hillary", "hillary@net.net", "3333333333");

            users.Add(u1);
            users.Add(u2);
            users.Add(u3);
            users.Add(u4);
            Console.WriteLine(users);
            



            return View("Test",users);
        }
    }
}